#ifndef MAIN_H_
#define MAIN_H_

#include <stdint.h>

void IRQ_Handler_global(void);
void delay(uint32_t t);

#endif /* MAIN_H_ */
